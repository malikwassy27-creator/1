# FirstPay Play Frontend

Standalone Next.js player website source. The shared, role-protected admin route is at `/admin`.

## Run locally

1. Copy `.env.example` to `.env.local` and set `NEXT_PUBLIC_API_URL` to your API origin.
2. Run `npm install`.
3. Run `npm run dev` for development, or `npm run build` and `npm start` for production.

Never place database URLs, signing secrets, or other server credentials in `NEXT_PUBLIC_*` variables.
