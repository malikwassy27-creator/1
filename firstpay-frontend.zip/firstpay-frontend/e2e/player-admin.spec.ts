import { test, expect, type Page } from "@playwright/test";
import { PrismaClient } from "@prisma/client";
import argon2 from "argon2";
import { createHash } from "node:crypto";

const prisma = new PrismaClient();
const prefix = `firstpay-e2e-${Date.now()}`;
const adminEmail = `${prefix}-admin@example.test`;
const adminPassword = "E2E-admin-password-strong-2026";
const playerPassword = "E2E-player-password-strong-2026";
const trackedUserIds: string[] = [];
const knownTransactionKeys: string[] = [];
let playerEmail = `${prefix}-player@example.test`;
let adminId = "";
let playerId = "";

test("web routes send the configured security headers", async ({ page }) => {
  const response = await page.goto("/");
  expect(response).not.toBeNull();
  const headers = response!.headers();
  expect(headers["x-frame-options"]).toBe("DENY");
  expect(headers["x-content-type-options"]).toBe("nosniff");
  expect(headers["content-security-policy"]).toContain("default-src 'self'");
  expect(headers["content-security-policy"]).toContain("frame-ancestors 'none'");
});

async function login(page: Page, email: string, password: string) {
  const loginResponse = page.waitForResponse((response) => response.url().endsWith("/auth/login") && response.request().method() === "POST");
  await page.goto("/login");
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(password);
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/lobby$/);
  return (await loginResponse).json() as Promise<{ accessToken: string; user: { id: string } }>;
}

async function getBalance(accessToken: string) {
  const response = await fetch("http://127.0.0.1:4000/cashier/summary", { headers: { authorization: `Bearer ${accessToken}` } });
  if (!response.ok) throw new Error(`Could not fetch cashier summary (${response.status})`);
  return Number(((await response.json()) as { wallet: { real_balance: string } }).wallet.real_balance);
}

test("register, deposit, play and verify roulette, then approve a €50 withdrawal", async ({ page }) => {
  test.setTimeout(240_000);
  const admin = await prisma.user.create({ data: { email: adminEmail, passwordHash: await argon2.hash(adminPassword), role: "ADMIN" } });
  adminId = admin.id; trackedUserIds.push(admin.id);
  await prisma.walletAccount.create({ data: { userId: admin.id, currency: "EUR" } });

  try {
    const registrationLogin = page.waitForResponse((response) => response.url().endsWith("/auth/login") && response.request().method() === "POST");
    await page.goto("/register");
    await page.getByLabel("Email").fill(playerEmail);
    await page.getByLabel("Password").fill(playerPassword);
    const consents = page.getByRole("checkbox");
    for (let index = 0; index < await consents.count(); index++) await consents.nth(index).check();
    await page.getByRole("button", { name: "Create account" }).click();
    await expect(page).toHaveURL(/\/lobby$/);
    const playerSession = await (await registrationLogin).json() as { accessToken: string; user: { id: string } };
    const player = await prisma.user.findUnique({ where: { email: playerEmail }, select: { id: true } });
    expect(player?.id).toBeTruthy();
    playerId = player!.id; trackedUserIds.push(playerId);

    await page.goto("/cashier");
    await page.locator("#deposit-amount").fill("100");
    await page.getByRole("button", { name: "Add credits" }).click();
    await expect(page.getByRole("status")).toContainText("Practice credits were added to your balance.");

    await page.goto("/games/roulette");
    await page.getByRole("button", { name: "Commit server seed" }).click();
    await expect(page.getByText("LIVE SERVER SEED HASH")).toBeVisible();
    await page.getByRole("button", { name: /^Spin ·/ }).click();
    await expect(page.locator(".round-result")).toBeVisible();
    await page.getByRole("link", { name: "Verify result" }).click();
    await expect(page.getByRole("heading", { name: "Verify this round" })).toBeVisible();
    await page.getByRole("button", { name: "Recompute" }).click();
    await expect(page.getByRole("status")).toHaveText("Verification result: Match");

    await page.goto("/cashier");
    const beforeWithdrawal = await getBalance(playerSession.accessToken);
    const withdrawalKey = `${prefix}-withdraw`;
    knownTransactionKeys.push(createHash("sha256").update(`${playerId}:${withdrawalKey}`).digest("hex"));
    await page.locator("#withdraw-amount").fill("50");
    await page.getByRole("button", { name: "Request withdrawal" }).click();
    await expect(page.getByRole("status")).toContainText("request is PENDING");
    await expect(page.getByText("PENDING", { exact: true }).first()).toBeVisible();
    await page.getByRole("button", { name: "Log out" }).click();

    await login(page, adminEmail, adminPassword);
    await page.goto("/admin");
    const requestRow = page.locator("tr").filter({ hasText: playerEmail });
    await expect(requestRow).toBeVisible();
    const approveKey = `${prefix}-approve`;
    knownTransactionKeys.push(createHash("sha256").update(`${adminId}:${approveKey}`).digest("hex"));
    await requestRow.getByRole("button", { name: "Approve" }).click();
    await expect(requestRow).toHaveCount(0);
    await page.getByRole("button", { name: "Log out" }).click();

    await login(page, playerEmail, playerPassword);
    const afterWithdrawal = await getBalance(playerSession.accessToken);
    expect(beforeWithdrawal - afterWithdrawal).toBe(50);
  } finally {
    await cleanup();
  }
});

async function cleanup() {
  const stale = await prisma.user.findMany({ where: { email: { startsWith: "firstpay-e2e-" } }, select: { id: true } });
  const userIds = [...new Set([...trackedUserIds.splice(0), ...stale.map((user) => user.id)])];
  const rounds = await prisma.gameRound.findMany({ where: { userId: { in: userIds } }, select: { id: true } });
  const withdrawals = await prisma.withdrawalRequest.findMany({ where: { userId: { in: userIds } }, select: { id: true } });
  const allWallets = await prisma.walletAccount.findMany({ where: { userId: { in: userIds } }, select: { id: true } });
  const txByWallet = allWallets.length ? await prisma.ledgerEntry.findMany({ where: { accountId: { in: allWallets.map((wallet) => wallet.id) } }, select: { transactionId: true } }) : [];
  const txs = await prisma.transaction.findMany({ where: { OR: [
    { id: { in: txByWallet.map((row) => row.transactionId) } },
    { idempotencyKey: { in: knownTransactionKeys } },
    ...userIds.map((userId) => ({ idempotencyKey: { startsWith: `${userId}:game:` } })),
    ...withdrawals.map((withdrawal) => ({ response: { path: ["withdrawalId"], equals: withdrawal.id } })),
  ] }, select: { id: true } });
  const roundIds = rounds.map((round) => round.id);
  const withdrawalIds = withdrawals.map((withdrawal) => withdrawal.id);
  await prisma.auditLog.deleteMany({ where: { OR: [
    { actorId: { in: userIds } },
    { targetId: { in: [...roundIds, ...withdrawalIds] } },
  ] } });
  await prisma.ledgerEntry.deleteMany({ where: { OR: [
    { transactionId: { in: txs.map((tx) => tx.id) } },
    { accountId: { in: allWallets.map((wallet) => wallet.id) } },
  ] } });
  await prisma.transaction.deleteMany({ where: { id: { in: txs.map((tx) => tx.id) } } });
  await prisma.seedCommitment.deleteMany({ where: { roundId: { in: roundIds } } });
  await prisma.bet.deleteMany({ where: { roundId: { in: roundIds } } });
  await prisma.gameRound.deleteMany({ where: { id: { in: roundIds } } });
  await prisma.paymentIntent.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.withdrawalRequest.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.limit.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.selfExclusion.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.walletAccount.deleteMany({ where: { userId: { in: userIds } } });
  await prisma.user.deleteMany({ where: { id: { in: userIds } } });
  knownTransactionKeys.length = 0;
}

test.afterAll(async () => prisma.$disconnect());
