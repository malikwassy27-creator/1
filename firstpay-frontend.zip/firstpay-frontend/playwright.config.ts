import { defineConfig, devices } from "@playwright/test";
import dotenv from "dotenv";
dotenv.config({ path: "../../.env" });
dotenv.config({ path: "../api/.env", override: false });

export default defineConfig({
  testDir: "./e2e",
  fullyParallel: false,
  workers: 1,
  timeout: 240_000,
  expect: { timeout: 20_000 },
  reporter: "list",
  use: { ...devices["Desktop Chrome"], baseURL: "http://127.0.0.1:3000", trace: "retain-on-failure" },
  webServer: [
    { command: "pnpm --dir ../api dev", url: "http://127.0.0.1:4000/health/live", env: { NODE_ENV: "test" }, reuseExistingServer: !process.env.CI, timeout: 120_000 },
    { command: "pnpm exec next dev --hostname 127.0.0.1", url: "http://127.0.0.1:3000", reuseExistingServer: !process.env.CI, timeout: 120_000 },
  ],
});
