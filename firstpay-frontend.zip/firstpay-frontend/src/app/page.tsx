import Link from "next/link";
import { ArrowRight, BadgeCheck, Bomb, CircleDot, Club, Diamond, ShieldCheck, Spade, WalletCards } from "lucide-react";
import { Button } from "@/components/ui/button";

const games = [
  { title: "Roulette", detail: "Numbers, colors and dozens", icon: <CircleDot/>, kind: "roulette" },
  { title: "Mines", detail: "Reveal tiles. Choose when to stop.", icon: <Bomb/>, kind: "mines" },
  { title: "Plinko", detail: "Set a risk level and follow the drop", icon: <span className="plinko-glyph">⋮</span>, kind: "plinko" },
  { title: "Blackjack", detail: "A quick hand against the dealer", icon: <Spade/>, kind: "blackjack" },
  { title: "Baccarat", detail: "Player, banker or tie", icon: <Club/>, kind: "baccarat" },
  { title: "Video Poker", detail: "Hold your cards and draw", icon: <Diamond/>, kind: "poker" },
];

export default function Home() {
  return <div className="landing-page">
    <section className="landing-hero">
      <div className="landing-copy"><p className="landing-overline"><span/> FIRSTPAY PLAY</p><h1>A better way<br/>to <em>play fair.</em></h1><p className="landing-lede">Six classic games, clear rules and a result you can verify after every round.</p><div className="landing-actions"><Button size="lg" asChild><Link href="/register">Create your account <ArrowRight size={16}/></Link></Button><Link href="/login" className="landing-login">Already registered? <span>Sign in</span></Link></div><div className="landing-points"><span><BadgeCheck size={16}/> Verifiable results</span><span><ShieldCheck size={16}/> Player controls</span></div></div>
      <div className="landing-showcase"><div className="showcase-orbit orbit-one"/><div className="showcase-orbit orbit-two"/><div className="showcase-chip"><span className="showcase-chip-label">THE GAME ROOM</span><div className="showcase-wheel"><div className="showcase-wheel-center"><CircleDot size={33}/><strong>00</strong></div></div><div className="showcase-stats"><span><b>06</b> games</span><i/><span><b>01</b> clear standard</span></div></div><div className="showcase-proof"><ShieldCheck size={16}/><span><strong>Every result has a proof</strong><small>Check the seed after the round</small></span><ArrowRight size={15}/></div></div>
    </section>

    <section className="landing-games"><div className="landing-section-head"><div><p className="landing-overline">PICK YOUR GAME</p><h2>Six tables. Your call.</h2></div><span className="catalog-note">A quick round or a little strategy</span></div><div className="landing-game-grid">{games.map(game => <Link key={game.title} href="/register" className={`landing-game game-${game.kind}`}><span className="landing-game-mark">{game.icon}</span><div><h3>{game.title}</h3><p>{game.detail}</p></div><ArrowRight className="landing-game-arrow" size={16}/></Link>)}</div></section>

    <section className="landing-responsibility"><span className="responsibility-mark"><WalletCards size={21}/></span><div><strong>Practice balance only</strong><p>Balances are simulated. Deposits do not use payment methods and cannot be withdrawn for cash. Payment processing is disabled.</p></div><Link href="/responsible-gambling">Player controls <ArrowRight size={14}/></Link></section>
  </div>;
}
