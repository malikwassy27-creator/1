import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function Privacy() {
  return <article className="terms-page"><p className="dashboard-kicker">FIRSTPAY PLAY · YOUR INFORMATION</p><h1>Privacy Notice</h1><p className="terms-lede">This notice summarizes the account information used by this application. The site is a practice environment and does not accept payment details.</p>
    <div className="terms-sections">
      <section><h2>Information used</h2><p>When you register, the service uses your email address and a password stored as a one-way password hash. It also creates account, wallet-ledger and game-round records needed to operate the account, display history and verify completed rounds.</p></section>
      <section><h2>Session security</h2><p>Sign-in uses short-lived access tokens and a refresh token held in a secure, HTTP-only cookie. The application uses these to keep your account signed in and to protect account-only actions.</p></section>
      <section><h2>Payments</h2><p>Payment processing is disabled. The application does not ask for or process card or bank details. Practice credits have no cash value.</p></section>
      <section><h2>Use of information</h2><p>Account information is used to authenticate you, provide wallet and game features, protect the service, and display your activity. It is not needed to advertise payment or gambling products.</p></section>
      <section><h2>Your choices</h2><p>You can log out, manage available play controls, and stop using the service. Contact the project operator to ask about access or deletion of account data. Any handling of such a request is subject to applicable law and operational requirements.</p></section>
    </div><Link className="terms-back" href="/register"><ArrowLeft size={15}/> Back to account creation</Link>
  </article>;
}
