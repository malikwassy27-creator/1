"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, BadgeCheck, CircleDot, ShieldCheck } from "lucide-react";
import { notifyWalletUpdated, post } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type Round = { round_id: string; server_seed_hash: string };
type DropResult = { result: { path: ("L" | "R")[]; bin: number; risk: string; multiplier: string; won: boolean }; verification: unknown };
export default function Plinko() {
  const [amount, setAmount] = useState("1.00");
  const [risk, setRisk] = useState<"low" | "medium" | "high">("medium");
  const [round, setRound] = useState<Round | null>(null);
  const [result, setResult] = useState<DropResult | null>(null);
  const [animatingResult, setAnimatingResult] = useState<DropResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const animationResolve = useRef<(() => void) | null>(null);
  async function start() {
    setBusy(true); setError(""); setResult(null);
    try { setRound(await post<Round>("/games/plinko/commit", { client_seed: `web-${crypto.randomUUID()}` })); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Could not prepare this round."); }
    finally { setBusy(false); }
  }
  async function drop() {
    if (!round || busy || result) return;
    setBusy(true); setError(""); setAnimatingResult(null);
    try {
      const settled = await post<DropResult>("/games/plinko/resolve", { round_id: round.round_id, amount, idempotency_key: crypto.randomUUID(), bet_type: "plinko", risk });
      setAnimatingResult(settled);
      await new Promise<void>(resolve => { animationResolve.current = resolve; });
      setResult(settled);
      setAnimatingResult(null);
      notifyWalletUpdated();
    }
    catch (reason) { setError(reason instanceof Error ? reason.message : "The drop could not be resolved. Your stake was not confirmed."); }
    finally { animationResolve.current = null; setBusy(false); }
  }
  function reset() { setRound(null); setResult(null); setAnimatingResult(null); setError(""); }
  const pathResult = animatingResult ?? result;
  const path = pathResult?.result.path ?? [];
  let rights = 0;
  const positions = path.map((step, index) => { if (step === "R") rights++; return { x: 180 + (2 * rights - index - 1) * 10.5, y: 10 + (index + 1) * 16 }; });
  const points = positions.map(point => `${point.x},${point.y}`);
  const polyline = `180,10 ${points.join(" ")}`;

  return <PlayerOnly>
    <Link href="/lobby#games" className="game-back"><ArrowLeft size={15}/> All games</Link>
<div className="game-page-head"><div><p className="dashboard-kicker">GAME ROOM / TABLE 03</p><h1>Plinko</h1><p>Choose a risk level, set your stake and let the server deal the path.</p></div></div>
    <div className="new-game-layout"><Card className="plinko-stage"><div className="stage-topline"><span><CircleDot size={14}/> 12 ROWS · 13 BINS</span><span>SERVER GENERATED PATH</span></div><div className="plinko-board"><svg viewBox="0 0 360 230" role="img" aria-label="Plinko board with twelve rows of pegs"><defs><linearGradient id="path-gradient" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#f5c542" stopOpacity=".62"/><stop offset="1" stopColor="#14f1c6"/></linearGradient><filter id="ball-glow"><feGaussianBlur stdDeviation="3" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>{Array.from({ length: 12 }, (_, row) => Array.from({ length: row + 1 }, (_, peg) => <circle key={`${row}-${peg}`} cx={180 - row * 10.5 + peg * 21} cy={10 + (row + 1) * 16} r="2.2" className="plinko-peg"/>))}{animatingResult && <motion.polyline points={polyline} initial={{ pathLength: 0, opacity: .4 }} animate={{ pathLength: 1, opacity: 1 }} transition={{ duration: 1.8, ease: "linear" }} fill="none" stroke="url(#path-gradient)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>}{pathResult && <motion.circle key={`${pathResult.result.path.join("")}-${pathResult.result.bin}`} initial={{ cx: 180, cy: 26, scale: .75 }} animate={{ cx: [180, ...positions.map(point => point.x).slice(1), 180 + (2 * rights - 12) * 10.5], cy: [26, ...positions.map(point => point.y).slice(1), 211], scale: 1 }} transition={{ duration: 1.8, ease: "easeInOut" }} onAnimationComplete={() => { if (animatingResult) animationResolve.current?.(); }} r="5" className="plinko-ball" filter="url(#ball-glow)"/>}{busy && !animatingResult && !result && <motion.circle cx="180" cy="10" r="5" className="plinko-ball" filter="url(#ball-glow)" initial={{ cy: 10, scale: .75 }} animate={{ cy: 26, scale: 1 }} transition={{ duration: .34, ease: "easeIn" }}/>}</svg><div className="plinko-bins">{Array.from({ length: 13 }, (_, index) => <span key={index} className={result?.result.bin === index ? "bin-hit" : ""}>{index}</span>)}</div></div>{result ? <div className={`plinko-outcome ${result.result.won ? "outcome-win" : "outcome-loss"}`}><div><span>BIN {result.result.bin} · {result.result.risk.toUpperCase()} RISK</span><strong>{result.result.multiplier}× return</strong><small>Estimated return: €{(Number(amount) * Number(result.result.multiplier)).toFixed(2)}</small></div><Link href={`/verify/${round?.round_id}`} className="verify-action">Verify path <ArrowRight size={14}/></Link></div> : <div className="plinko-hint">{busy ? "Getting the server path…" : round ? "Your commitment is live. Drop the ball to resolve." : "The server sets the path from your committed seed."}</div>}{round && <div className="mines-commitment"><div><ShieldCheck size={14}/> SEED COMMITMENT</div><code>{round.server_seed_hash}</code></div>}</Card>
      <Card className="new-game-controls"><div className="bet-panel-heading"><div><p className="dashboard-kicker">ROUND SETUP</p><CardTitle className="mt-2">Drop a ball</CardTitle></div><span className="round-icon"><CircleDot size={17}/></span></div><div className="bet-field"><label className="label" htmlFor="plinko-amount">Stake amount <span>EUR</span></label><div className="amount-control"><button type="button" onClick={() => setAmount((Math.max(.1, Number(amount) / 2)).toFixed(2))} disabled={Boolean(result) || busy}>½</button><input id="plinko-amount" type="number" min="0.01" step="0.01" value={amount} onChange={event => setAmount(event.target.value)} disabled={Boolean(result) || busy}/><button type="button" onClick={() => setAmount((Number(amount) * 2).toFixed(2))} disabled={Boolean(result) || busy}>2×</button></div></div><div className="bet-field"><span className="label">Risk profile</span><div className="risk-options">{(["low", "medium", "high"] as const).map(option => <button type="button" key={option} className={risk === option ? `risk-${option} selected` : `risk-${option}`} disabled={Boolean(result) || busy} onClick={() => setRisk(option)}><strong>{option}</strong><span>{option === "low" ? "Smoother" : option === "medium" ? "Balanced" : "Volatile"}</span></button>)}</div></div>{error && <p role="alert" className="error">{error}</p>}{!round ? <Button className="w-full game-primary-action" disabled={busy || Number(amount) <= 0} onClick={() => void start()}>{busy ? "Committing seed…" : "Commit round"}<ArrowRight size={15}/></Button> : !result ? <Button className="w-full game-primary-action" aria-busy={busy} disabled={busy} onClick={() => void drop()}>{busy ? <><span className="button-spinner"/> Dropping…</> : `Drop · €${amount}`}<CircleDot size={15}/></Button> : <Button className="w-full game-primary-action" variant="outline" onClick={reset}>Play again <ArrowRight size={15}/></Button>}<div className="bet-security"><BadgeCheck size={14}/><span>Each peg direction comes from the server seed. The revealed proof can be recomputed after the drop.</span></div></Card></div>
  </PlayerOnly>;
}
