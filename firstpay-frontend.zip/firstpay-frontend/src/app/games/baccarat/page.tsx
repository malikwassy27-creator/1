"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowLeft, ArrowRight, BadgeCheck, ShieldCheck, Spade } from "lucide-react";
import { post } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type Round = { round_id: string; server_seed_hash: string };
type PlayingCard = { rank: number; suit: string };
type Result = { result: { player: PlayingCard[]; banker: PlayingCard[]; player_score: number; banker_score: number; winner: string; bet_type: string; won: boolean; multiplier: string }; verification: unknown };
const face = (rank: number) => rank === 1 ? "A" : rank === 11 ? "J" : rank === 12 ? "Q" : rank === 13 ? "K" : String(rank);

export default function Baccarat() {
  const [amount, setAmount] = useState("1.00");
  const [bet, setBet] = useState<"player" | "banker" | "tie">("player");
  const [round, setRound] = useState<Round | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function commit() {
    setBusy(true); setError(""); setResult(null);
    try { setRound(await post<Round>("/games/baccarat/commit", { client_seed: `web-${crypto.randomUUID()}` })); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Could not prepare the shoe."); }
    finally { setBusy(false); }
  }
  async function deal() {
    if (!round) return;
    setBusy(true); setError("");
    try { setResult(await post<Result>("/games/baccarat/resolve", { round_id: round.round_id, amount, idempotency_key: crypto.randomUUID(), bet_type: bet })); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "The hand could not be settled. Your stake was not confirmed."); }
    finally { setBusy(false); }
  }
  function reset() { setRound(null); setResult(null); setError(""); }
  const payout = result?.result.won ? Number(amount) * Number(result.result.multiplier) : 0;
  const betOptions: { value: typeof bet; label: string; return: string }[] = [{ value: "player", label: "Player", return: "2×" }, { value: "banker", label: "Banker", return: "1.95×" }, { value: "tie", label: "Tie", return: "8×" }];

  return <PlayerOnly><Link href="/lobby#games" className="game-back"><ArrowLeft size={15}/> All games</Link><div className="game-page-head"><div><p className="dashboard-kicker">CARD ROOM / TABLE 05</p><h1>Baccarat</h1><p>Bet on Player, Banker or Tie. Cards are dealt using standard baccarat drawing rules.</p></div></div>
    <div className="new-game-layout"><Card className="card-table baccarat-table"><div className="card-table-heading"><span><Spade size={15}/> BACCARAT · PLAYER VS BANKER</span><span>HIGHEST SCORE: 9</span></div><div className="baccarat-hands"><BaccaratHand title="PLAYER" score={result?.result.player_score} cards={result?.result.player}/><div className="baccarat-vs">VS</div><BaccaratHand title="BANKER" score={result?.result.banker_score} cards={result?.result.banker}/></div>{result && <div className={`card-outcome ${result.result.won ? "outcome-win" : "outcome-loss"}`}><div><span>WINNER · {result.result.winner.toUpperCase()}</span><strong>{result.result.won ? `Winning return · €${payout.toFixed(2)}` : `Your pick: ${result.result.bet_type}`}</strong></div><Link href={`/verify/${round?.round_id}`} className="verify-action">Verify hand <ArrowRight size={14}/></Link></div>}{round && <div className="mines-commitment"><div><ShieldCheck size={14}/> SHOE COMMITTED BEFORE DEAL</div><code>{round.server_seed_hash}</code></div>}</Card>
      <Card className="new-game-controls"><div className="bet-panel-heading"><div><p className="dashboard-kicker">ROUND SETUP</p><CardTitle className="mt-2">Choose your side</CardTitle></div><span className="round-icon"><Spade size={17}/></span></div><div className="baccarat-bets">{betOptions.map(option => <button key={option.value} type="button" className={`baccarat-bet ${bet === option.value ? "selected" : ""}`} onClick={() => setBet(option.value)} disabled={Boolean(result) || busy}><span>{option.label}</span><strong>{option.return}</strong></button>)}</div><p className="baccarat-commission">Banker return includes a 5% commission.</p><div className="bet-field"><label className="label" htmlFor="baccarat-amount">Stake amount <span>EUR</span></label><div className="amount-control"><button type="button" onClick={() => setAmount((Math.max(.1, Number(amount) / 2)).toFixed(2))} disabled={Boolean(result) || busy}>½</button><input id="baccarat-amount" type="number" min="0.01" step="0.01" value={amount} onChange={event => setAmount(event.target.value)} disabled={Boolean(result) || busy}/><button type="button" onClick={() => setAmount((Number(amount) * 2).toFixed(2))} disabled={Boolean(result) || busy}>2×</button></div></div>{error && <p role="alert" className="error">{error}</p>}{!round ? <Button className="w-full game-primary-action" disabled={busy || Number(amount) <= 0} onClick={() => void commit()}>{busy ? "Committing shoe…" : "Commit round"}<ArrowRight size={15}/></Button> : !result ? <Button className="w-full game-primary-action" disabled={busy} onClick={() => void deal()}>{busy ? "Dealing cards…" : `Deal · €${amount}`}<Spade size={15}/></Button> : <Button className="w-full game-primary-action" variant="outline" onClick={reset}>Play another hand <ArrowRight size={15}/></Button>}<div className="bet-security"><BadgeCheck size={14}/><span>Both hands and all draws are generated from the committed server seed.</span></div></Card></div>
  </PlayerOnly>;
}

function BaccaratHand({ title, score, cards }: { title: string; score?: number; cards?: PlayingCard[] }) { return <div className="baccarat-hand"><p>{title}<strong>{score ?? "—"}</strong></p><div className="card-row">{cards ? cards.map((card, index) => <PlayingCard key={index} card={card}/>) : <><div className="card-back">?</div><div className="card-back">?</div></>}</div></div>; }
function PlayingCard({ card }: { card: PlayingCard }) { const rank = card.rank === 1 ? "A" : card.rank === 11 ? "J" : card.rank === 12 ? "Q" : card.rank === 13 ? "K" : String(card.rank); return <div className={`playing-card ${card.suit === "♥" || card.suit === "♦" ? "red-card" : ""}`}><strong>{rank}</strong><span>{card.suit}</span></div>; }
