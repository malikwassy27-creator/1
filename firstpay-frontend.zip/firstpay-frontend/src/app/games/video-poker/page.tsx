"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowLeft, ArrowRight, BadgeCheck, Diamond, ShieldCheck } from "lucide-react";
import { post } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type Round = { round_id: string; server_seed_hash: string };
type PlayingCard = { rank: number; suit: string };
type Deal = { cards: PlayingCard[]; server_seed_hash: string };
type Result = { result: { initial: PlayingCard[]; holds: number[]; cards: PlayingCard[]; hand: string; multiplier: string; won: boolean }; verification: unknown };
const rankLabel = (rank: number) => rank === 1 ? "A" : rank === 11 ? "J" : rank === 12 ? "Q" : rank === 13 ? "K" : String(rank);

export default function VideoPoker() {
  const [amount, setAmount] = useState("1.00");
  const [round, setRound] = useState<Round | null>(null);
  const [hand, setHand] = useState<PlayingCard[]>([]);
  const [holds, setHolds] = useState<number[]>([]);
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function deal() {
    setBusy(true); setError("");
    try {
      let currentRound = round;
      if (!currentRound) { currentRound = await post<Round>("/games/video-poker/commit", { client_seed: `web-${crypto.randomUUID()}` }); setRound(currentRound); }
      const response = await post<Deal>("/games/video-poker/deal", { round_id: currentRound.round_id });
      setHand(response.cards); setHolds([]); setResult(null);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not deal an opening hand. Retry the deal."); }
    finally { setBusy(false); }
  }
  async function draw() {
    if (!round || hand.length !== 5) return;
    setBusy(true); setError("");
    try { setResult(await post<Result>("/games/video-poker/resolve", { round_id: round.round_id, amount, idempotency_key: crypto.randomUUID(), bet_type: "poker", holds })); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "The draw could not be resolved. Your stake was not confirmed."); }
    finally { setBusy(false); }
  }
  function reset() { setRound(null); setHand([]); setHolds([]); setResult(null); setError(""); }
  function toggle(index: number) { setHolds(previous => previous.includes(index) ? previous.filter(value => value !== index) : [...previous, index]); }
  const displayedCards = result?.result.cards ?? hand;
  const payout = result?.result.won ? Number(amount) * Number(result.result.multiplier) : 0;

  return <PlayerOnly><Link href="/lobby#games" className="game-back"><ArrowLeft size={15}/> All games</Link><div className="game-page-head"><div><p className="dashboard-kicker">CARD ROOM / TABLE 06</p><h1>Video Poker</h1><p>Hold the cards you want to keep. The server draws replacements and settles the hand.</p></div></div>
    <div className="new-game-layout"><Card className="card-table poker-table"><div className="card-table-heading"><span><Diamond size={15}/> FIVE CARD DRAW</span><span>JACKS OR BETTER</span></div><div className="poker-hand">{displayedCards.length === 5 ? displayedCards.map((card, index) => <button type="button" key={index} className={`poker-hold-card ${holds.includes(index) && !result ? "held" : ""} ${card.suit === "♥" || card.suit === "♦" ? "red-card" : ""}`} onClick={() => !result && toggle(index)} disabled={!hand.length || Boolean(result) || busy} aria-pressed={holds.includes(index)}><span className="poker-card-rank">{rankLabel(card.rank)}</span><span className="poker-card-suit">{card.suit}</span>{holds.includes(index) && !result && <small>HOLD</small>}</button>) : <div className="poker-empty">Commit a round to deal five cards.</div>}</div>{hand.length > 0 && !result && <p className="hold-instruction">Select cards to hold, then draw to replace the rest.</p>}{result && <div className={`card-outcome ${result.result.won ? "outcome-win" : "outcome-loss"}`}><div><span>{result.result.hand.replaceAll("_", " ")}</span><strong>{result.result.won ? `Return · €${payout.toFixed(2)} (${result.result.multiplier}×)` : "No winning combination"}</strong></div><Link href={`/verify/${round?.round_id}`} className="verify-action">Verify draw <ArrowRight size={14}/></Link></div>}{round && <div className="mines-commitment"><div><ShieldCheck size={14}/> SEED COMMITTED BEFORE DEAL</div><code>{round.server_seed_hash}</code></div>}</Card>
      <Card className="new-game-controls"><div className="bet-panel-heading"><div><p className="dashboard-kicker">ROUND SETUP</p><CardTitle className="mt-2">Set your stake</CardTitle></div><span className="round-icon"><Diamond size={17}/></span></div><div className="poker-paytable"><span>Royal flush <strong>250×</strong></span><span>Straight flush <strong>50×</strong></span><span>Four of a kind <strong>25×</strong></span><span>Full house <strong>9×</strong></span><span>Flush <strong>6×</strong></span><span>Straight <strong>4×</strong></span><span>Three of a kind <strong>3×</strong></span><span>Two pair <strong>2×</strong></span><span>Jacks or better <strong>1×</strong></span></div><div className="bet-field"><label className="label" htmlFor="poker-amount">Stake amount <span>EUR</span></label><div className="amount-control"><button type="button" onClick={() => setAmount((Math.max(.1, Number(amount) / 2)).toFixed(2))} disabled={Boolean(result) || busy}>½</button><input id="poker-amount" type="number" min="0.01" step="0.01" value={amount} onChange={event => setAmount(event.target.value)} disabled={Boolean(result) || busy}/><button type="button" onClick={() => setAmount((Number(amount) * 2).toFixed(2))} disabled={Boolean(result) || busy}>2×</button></div></div>{error && <p role="alert" className="error">{error}</p>}{result ? <Button className="w-full game-primary-action" variant="outline" onClick={reset}>Play another hand <ArrowRight size={15}/></Button> : hand.length ? <Button className="w-full game-primary-action" disabled={busy} onClick={() => void draw()}>{busy ? "Drawing cards…" : `Draw · €${amount}`}<Diamond size={15}/></Button> : <Button className="w-full game-primary-action" disabled={busy || Number(amount) <= 0} onClick={() => void deal()}>{busy ? "Dealing opening hand…" : round ? "Retry opening deal" : "Commit and deal"}<ArrowRight size={15}/></Button>}<div className="bet-security"><BadgeCheck size={14}/><span>Cards are deterministic from the committed seed, but generated and evaluated on the server.</span></div></Card></div>
  </PlayerOnly>;
}
