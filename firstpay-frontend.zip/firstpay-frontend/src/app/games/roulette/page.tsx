"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, BadgeCheck, CircleDot, RotateCcw, ShieldCheck } from "lucide-react";
import { post, notifyWalletUpdated } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GameIntel, useRecentRounds } from "@/components/game-intel";

type Round = { round_id: string; server_seed_hash: string };
type GameResult = { result: { number: number; bet_type: string; selection: number | null; won: boolean }; verification: { server_seed: string; server_seed_hash: string; client_seed: string; nonce: number } };
const red = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
const cellTone = (value: number) => value === 0 ? "green" : red.has(value) ? "red" : "black";

export default function Roulette() {
  const [amount, setAmount] = useState("1.00");
  const [type, setType] = useState("red");
  const [selection, setSelection] = useState("7");
  const [round, setRound] = useState<Round | null>(null);
  const [result, setResult] = useState<GameResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [spinPhase, setSpinPhase] = useState<"idle" | "spinning" | "waiting" | "settling">("idle");
  const [wheelAngle, setWheelAngle] = useState(0);
  const { rounds, remember } = useRecentRounds("roulette");

  async function commit() {
    setBusy(true); setError(""); setResult(null);
    try { setRound(await post<Round>("/games/roulette/commit", { client_seed: `web-${crypto.randomUUID()}` })); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Could not prepare the round. Check your connection and try again."); }
    finally { setBusy(false); }
  }
  async function spin() {
    if (!round || busy || spinPhase !== "idle") return;
    setBusy(true); setError(""); setResult(null); setWheelAngle(1440); setSpinPhase("spinning");
    let waitingTimer: number | undefined;
    try {
      const payload = { round_id: round.round_id, amount, idempotency_key: crypto.randomUUID(), bet_type: type, ...(type === "number" || type === "dozen" ? { selection: Number(selection) } : {}) };
      waitingTimer = window.setTimeout(() => setSpinPhase(current => current === "spinning" ? "waiting" : current), 3050);
      const [settled] = await Promise.all([post<GameResult>("/games/roulette/resolve", payload), new Promise<void>(resolve => window.setTimeout(resolve, 3000))]);
      if (waitingTimer) window.clearTimeout(waitingTimer);
      setSpinPhase("settling");
      setWheelAngle(1800 - settled.result.number * (360 / 37));
      await new Promise<void>(resolve => window.setTimeout(resolve, 480));
      setResult(settled);
      notifyWalletUpdated();
      remember({ id: round.round_id, label: `${settled.result.number} · ${settled.result.won ? "Win" : "No win"}`, won: settled.result.won, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) });
    } catch (reason) { if (waitingTimer) window.clearTimeout(waitingTimer); setError(reason instanceof Error ? reason.message : "Could not resolve the round. Your stake was not confirmed."); setWheelAngle(0); }
    finally { setSpinPhase("idle"); setBusy(false); }
  }
  function reset() { setRound(null); setResult(null); setError(""); setWheelAngle(0); setSpinPhase("idle"); }
  const number = result?.result.number;
  const tone = number === undefined ? "" : cellTone(number);
  const payout = result?.result.won ? Number(amount) * (result.result.bet_type === "number" ? 36 : result.result.bet_type === "dozen" ? 3 : 2) : 0;

  return <PlayerOnly>
    <Link href="/lobby#games" className="game-back"><ArrowLeft size={15}/> All games</Link>
    <div className="game-page-head"><div><p className="dashboard-kicker">GAME ROOM / TABLE 01</p><h1>Roulette</h1><p>One stake, one server generated result. The seed commitment is visible before the spin.</p></div></div>
    <div className="roulette-layout">
      <Card className="roulette-stage">
        <div className="stage-topline"><span><CircleDot size={15}/> EUROPEAN ROULETTE</span><span>0–36 · SINGLE ZERO</span></div>
        <div className={`roulette-wheel ${result ? "has-result" : ""}`}>
          <div className={`wheel-rim ${spinPhase === "spinning" ? "is-spinning" : spinPhase === "waiting" ? "is-waiting" : spinPhase === "settling" ? "is-settling" : ""}`} style={{ transform: `rotate(${wheelAngle}deg)` }}><div className="wheel-number-ring">{Array.from({ length: 37 }, (_, i) => <span key={i} className={`wheel-pocket pocket-${cellTone(i)}`} style={{ transform: `rotate(${i * (360 / 37)}deg)` }}>{i}</span>)}</div><div className={`wheel-result ${tone}`}>{number ?? <CircleDot size={31}/>}</div></div>
          <span className="wheel-pointer" />
        </div>
        <div className="spin-caption">{result ? <><span className={`result-chip ${tone}`}>{number}</span><span>{result.result.won ? "Winning selection" : "No win this round"}</span></> : <span>{round ? "Your seed is committed. Place the round to spin." : "The wheel is ready when you are."}</span>}</div>
        {round && <div className="commitment-box"><div className="commitment-title"><ShieldCheck size={14}/> COMMITMENT · CREATED BEFORE PLAY</div><code>{round.server_seed_hash}</code><div className="commitment-caption">This hash fixes the server seed before the outcome is generated.</div></div>}
        {result && <div className="round-result"><div><span className="result-label">ROUND RESULT</span><strong>{result.result.won ? `Winning payout · €${payout.toFixed(2)}` : "This round did not pay"}</strong><span className="round-result-detail">{result.result.bet_type === "number" ? "36×" : result.result.bet_type === "dozen" ? "3×" : "2×"} stake return · verify the outcome below</span></div><Link href={`/verify/${round?.round_id}`} className="verify-action">Verify result <ArrowRight size={14}/></Link></div>}
      </Card>
      <div className="game-side-column"><Card className="bet-panel">
        <div className="bet-panel-heading"><div><p className="dashboard-kicker">YOUR WAGER</p><CardTitle className="mt-2">Set up a round</CardTitle></div><span className="round-icon"><CircleDot size={18}/></span></div>
        <div className="bet-field"><label className="label" htmlFor="roulette-amount">Stake amount <span>EUR</span></label><div className="amount-control"><button type="button" onClick={() => setAmount((Math.max(0.1, Number(amount) / 2)).toFixed(2))} disabled={Boolean(result) || busy}>½</button><input id="roulette-amount" inputMode="decimal" type="number" min="0.01" step="0.01" value={amount} onChange={event => setAmount(event.target.value)} disabled={Boolean(result) || busy} /><button type="button" onClick={() => setAmount((Number(amount) * 2).toFixed(2))} disabled={Boolean(result) || busy}>2×</button></div><div className="stake-chips">{["1.00", "2.50", "5.00", "10.00"].map(chip => <button type="button" key={chip} className={amount === chip ? "selected" : ""} onClick={() => setAmount(chip)} disabled={Boolean(result) || busy}>€{Number(chip)}</button>)}</div></div>
        <div className="bet-field"><label className="label" htmlFor="bet-type">Choose a bet</label><select id="bet-type" className="field bet-select" value={type} onChange={event => setType(event.target.value)} disabled={Boolean(result) || busy}><option value="red">Red · pays 2×</option><option value="black">Black · pays 2×</option><option value="number">Single number · pays 36×</option><option value="dozen">Dozen · pays 3×</option></select></div>
        {(type === "number" || type === "dozen") && <div className="bet-field"><label className="label" htmlFor="selection">{type === "number" ? "Choose number (0–36)" : "Choose dozen"}</label>{type === "number" ? <div className="number-picker">{Array.from({ length: 37 }, (_, n) => <button type="button" aria-pressed={selection === String(n)} key={n} className={`number-${cellTone(n)} ${selection === String(n) ? "picked" : ""}`} onClick={() => setSelection(String(n))} disabled={Boolean(result) || busy}>{n}</button>)}</div> : <select id="selection" className="field bet-select" value={selection} onChange={event => setSelection(event.target.value)} disabled={Boolean(result) || busy}><option value="1">1st dozen · 1–12</option><option value="2">2nd dozen · 13–24</option><option value="3">3rd dozen · 25–36</option></select>}</div>}
        {error && <p role="alert" className="notice-error">{error}</p>}
        {!round ? <Button className="w-full game-primary-action" disabled={busy || !/^\d+(\.\d{1,2})?$/.test(amount) || Number(amount) <= 0} onClick={() => void commit()}>{busy ? "Preparing commitment…" : "Commit server seed"}<ArrowRight size={16}/></Button> : !result ? <Button className="w-full game-primary-action" aria-busy={busy} disabled={busy} onClick={() => void spin()}>{busy ? <><span className="button-spinner"/> Spinning…</> : `Spin · €${amount}`}<CircleDot size={16}/></Button> : <Button className="w-full game-primary-action" variant="outline" onClick={reset}><RotateCcw size={15}/> Play another round</Button>}
        <div className="bet-security"><BadgeCheck size={14}/><span>Every result is computed by the server and can be checked with its revealed seed.</span></div>
      </Card><GameIntel hash={round?.server_seed_hash} rounds={rounds}/></div>
    </div>
  </PlayerOnly>;
}
