"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ArrowDownLeft, ArrowRight, ArrowUpRight, BadgeCheck, Bomb, CircleDot, Clock3, Coins, Dice5, Plus, RefreshCw, Rocket, ShieldCheck, WalletCards, Waves } from "lucide-react";
import { api } from "@/lib/api";
import { PlayerOnly } from "@/components/require-auth";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";

type LedgerRow = { direction: "CREDIT" | "DEBIT"; amount: string; currency: string };
type Activity = { id: string; type: string; status: string; created_at: string; entries: LedgerRow[] };
type Summary = { wallet: { real_balance: string; bonus_balance: string; currency: string }; transactions: Activity[]; withdrawals: { id: string; amount: string; status: string }[]; deposits: unknown[] };
const money = (value: string, currency: string) => new Intl.NumberFormat(undefined, { style: "currency", currency, minimumFractionDigits: 2 }).format(Number(value));
const label = (type: string) => type.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());

export default function Lobby() {
  const { user } = useAuth();
  const [data, setData] = useState<Summary | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const refresh = useCallback(async (quiet = false) => {
    if (quiet) setRefreshing(true); else setLoading(true);
    setError("");
    try { setData(await api<Summary>("/cashier/summary")); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Could not load your wallet activity."); }
    finally { setLoading(false); setRefreshing(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  return <PlayerOnly>
    <div className="dashboard-heading">
      <div><p className="dashboard-kicker">PLAYER OVERVIEW <span className="live-dot" /></p><h1>Good to see you.</h1><p className="dashboard-subtitle">Your wallet, recent activity and games in one place.</p></div>
      <Button variant="outline" size="sm" onClick={() => void refresh(true)} disabled={refreshing}><RefreshCw size={14} className={refreshing ? "animate-spin" : ""} /> Refresh</Button>
    </div>

    {error && <div role="alert" className="notice-error"><span>{error}</span><Button size="sm" variant="outline" onClick={() => void refresh()}>Try again</Button></div>}

    <section className="lobby-hero"><div className="lobby-hero-copy"><p className="lobby-hero-eyebrow"><span/> YOUR GAME ROOM</p><h2>Welcome back{user?.email ? `, ${user.email.split("@")[0]}` : ""}.</h2><p>Your balance, recent activity and favorite tables are ready when you are.</p><div className="lobby-hero-actions"><Button asChild><Link href="/cashier"><Plus size={16}/> Add practice credits</Link></Button><Link href="#games">Browse games <ArrowRight size={15}/></Link></div><small>Practice credits only · payment processing is disabled</small></div><div className="lobby-hero-art" aria-hidden="true"><div className="hero-orbit hero-orbit-a"/><div className="hero-orbit hero-orbit-b"/><div className="hero-chip"><span>FP</span></div><div className="hero-art-card hero-card-one">7<small>♠</small></div><div className="hero-art-card hero-card-two">K<small>♦</small></div><div className="hero-art-line">PLAY WITH CLARITY</div></div></section>

    <section aria-label="Wallet balances" className="balance-grid">
      <Card className="balance-card balance-primary">
        <div className="balance-label"><span className="balance-icon"><WalletCards size={17}/></span><span>AVAILABLE BALANCE</span></div>
        <p className="balance-value">{loading ? <span className="skeleton-text">Loading balance</span> : data ? money(data.wallet.real_balance, data.wallet.currency) : "—"}</p>
        <p className="balance-caption">Practice balance · no payment processing</p>
        <Link className="balance-action" href="/cashier">Wallet details <ArrowRight size={14}/></Link>
      </Card>
      <Card className="balance-card">
        <div className="balance-label"><span className="balance-icon brass"><BadgeCheck size={16}/></span><span>BONUS BALANCE</span></div>
        <p className="balance-value">{loading ? <span className="skeleton-text">Loading balance</span> : data ? money(data.wallet.bonus_balance, data.wallet.currency) : "—"}</p>
        <p className="balance-caption">Tracked separately from your main balance</p>
      </Card>
      <Card className="wallet-shortcut">
        <p className="shortcut-kicker">WALLET ACTIONS</p>
        <h2>Manage your funds</h2>
        <p>Manage practice credits and review withdrawal requests in your account history.</p>
        <div className="shortcut-actions"><Button size="sm" asChild><Link href="/cashier"><Plus size={14}/> Deposit</Link></Button><Button size="sm" variant="outline" asChild><Link href="/cashier#withdraw"><ArrowDownLeft size={14}/> Withdraw</Link></Button></div>
      </Card>
    </section>

    <section id="games" className="section-block">
      <div className="section-heading"><div><p className="dashboard-kicker">THE GAME ROOM</p><h2>Choose your table</h2></div><span className="section-note"><ShieldCheck size={14}/> Server resolved · Independently verifiable</span></div>
      <div className="game-grid">
        <Link href="/games/roulette" className="game-card roulette-card"><div className="game-art roulette-art"><div className="roulette-rings"><div className="roulette-center"><CircleDot size={28}/><span>00</span></div></div><span className="art-tag">EUROPEAN</span></div><GameCardCopy type="NUMBER · COLOR · DOZEN" title="Roulette" description="Choose a number, color or dozen. The wheel settles on a server generated result." tone="mint"/></Link>
        <Link href="/games/mines" className="game-card mines-card"><div className="game-art mines-art"><div className="mines-preview" aria-hidden="true">{Array.from({ length: 25 }, (_, index) => <span key={index} className={index === 6 || index === 18 ? "mine-hint" : index === 12 || index === 20 ? "safe-hint" : ""}>{index === 6 || index === 18 ? "×" : index === 12 || index === 20 ? "◆" : ""}</span>)}</div><span className="art-tag">5 × 5 BOARD</span></div><GameCardCopy type="PICK · BUILD · CASH OUT" title="Mines" description="Reveal tiles one at a time and cash out your growing multiplier whenever you choose." tone="mint"/></Link>
        <Link href="/games/plinko" className="game-card plinko-card"><div className="game-art plinko-art"><div className="plinko-preview" aria-hidden="true">{Array.from({ length: 7 }, (_, row) => <span key={row}>{Array.from({ length: row + 1 }, (_, dot) => <i key={dot}/>)}</span>)}</div><span className="art-tag">12 ROWS</span></div><GameCardCopy type="CHOOSE YOUR RISK" title="Plinko" description="Set a stake and risk level, then follow the server generated path to a payout bin." tone="brass"/></Link>
        <ComingSoon title="Blackjack" detail="Classic dealer table" icon={<span>♠</span>} className="soon-cards"/>
        <ComingSoon title="Crash" detail="Watch the multiplier climb" icon={<Rocket size={27}/>} className="soon-crash"/>
        <ComingSoon title="Dice" detail="Set your target and roll" icon={<Dice5 size={28}/>} className="soon-dice"/>
        <ComingSoon title="Slots" detail="A classic reel experience" icon={<span className="slot-glyph">7</span>} className="soon-slots"/>
        <ComingSoon title="Coinflip" detail="Pick a side of the coin" icon={<Coins size={28}/>} className="soon-coin"/>
        <ComingSoon title="Baccarat" detail="Player, banker or tie" icon={<Waves size={28}/>} className="soon-baccarat"/>
      </div>
      <p className="responsible-inline"><span>18+</span> Set personal limits and take a break whenever you need one. <Link href="/responsible-gambling">Play controls <ArrowUpRight size={12}/></Link></p>
    </section>

    <section className="section-block activity-section" id="activity">
      <div className="section-heading"><div><p className="dashboard-kicker">ACCOUNT RECORD</p><h2>Recent activity</h2></div><Button variant="ghost" size="sm" asChild><Link href="/cashier#activity">Full wallet history <ArrowRight size={14}/></Link></Button></div>
      <Card className="activity-card">
        {loading ? <div className="activity-loading"><span className="loading-bar"/><span className="loading-bar"/><span className="loading-bar"/></div> : !data ? <div className="empty-state"><p>Your activity is temporarily unavailable.</p><Button size="sm" variant="outline" onClick={() => void refresh()}>Reload</Button></div> : data.transactions.length === 0 ? <div className="empty-state"><span className="empty-icon"><Clock3 size={19}/></span><p className="empty-title">Nothing here yet</p><p>Your deposits, withdrawals and game rounds will show here.</p><Button size="sm" variant="outline" asChild><Link href="/cashier">Open wallet</Link></Button></div> : <div className="table-wrap"><table><thead><tr><th>Activity</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead><tbody>{data.transactions.slice(0, 6).map((row) => <tr key={row.id}><td><span className="activity-name"><span className="activity-symbol">{row.type.includes("DEPOSIT") ? "+" : row.type.includes("WITHDRAW") || row.type.includes("BET") ? "−" : "•"}</span>{label(row.type)}</span></td><td>{row.entries.length ? row.entries.filter((entry) => entry.direction === "DEBIT").map((entry) => `−${money(entry.amount, entry.currency)}`).join(" ") || row.entries.filter((entry) => entry.direction === "CREDIT").map((entry) => `+${money(entry.amount, entry.currency)}`).join(" ") : "—"}</td><td><span className={`status-pill status-${row.status.toLowerCase()}`}>{label(row.status)}</span></td><td className="activity-date">{new Date(row.created_at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</td></tr>)}</tbody></table></div>}
      </Card>
    </section>
  </PlayerOnly>;
}

function ComingSoon({ title, detail, icon, className }: { title: string; detail: string; icon: React.ReactNode; className: string }) {
  return <article className={`game-card coming-game ${className}`} aria-label={`${title}, coming soon`}><div className="game-art coming-art"><div className="coming-art-orbit"/><div className="coming-art-icon">{icon}</div><span className="coming-badge">COMING SOON</span></div><div className="game-copy"><div className="game-copy-top"><span className="game-type">ON THE WAY</span><Waves size={15}/></div><h3>{title}</h3><p>{detail}</p><div className="game-bottom"><span>New table</span><span className="coming-note">In development</span></div></div></article>;
}

function GameCardCopy({ type, title, description, tone }: { type: string; title: string; description: string; tone: "mint" | "brass" }) {
  return <div className="game-copy"><div className="game-copy-top"><span className="game-type">{type}</span><ArrowUpRight size={16}/></div><h3>{title}</h3><p>{description}</p><div className="game-bottom"><span><BadgeCheck size={13}/> Server resolved</span><span className={`game-cta ${tone}`}>Play game <ArrowRight size={13}/></span></div></div>;
}
