import type { Metadata } from "next";
import { Inter, Outfit } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/lib/auth";
import { Shell } from "@/components/shell";
const outfit = Outfit({ subsets: ["latin"], variable: "--font-outfit", display: "swap" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
export const metadata: Metadata = { title: "FirstPay Play", description: "Fair play. Clear rules. Play responsibly." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en" className={`${outfit.variable} ${inter.variable}`}><body><AuthProvider><Shell>{children}</Shell></AuthProvider></body></html>; }
