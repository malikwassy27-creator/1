export const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:4000";
export type ApiUser = { id: string; email: string; role: "PLAYER" | "ADMIN" };
export type AuthSession = { accessToken: string; user: ApiUser };
let accessToken: string | null = null;
export function setAccessToken(token: string | null) { accessToken = token; }
export function getToken() { return accessToken; }
export function notifyWalletUpdated() {
  if (typeof window !== "undefined") window.dispatchEvent(new Event("firstpay:wallet-updated"));
}
let refreshRequest: Promise<AuthSession | null> | null = null;
export function refreshSession(): Promise<AuthSession | null> {
  if (!refreshRequest) refreshRequest = fetch(`${API_URL}/auth/refresh`, { method: "POST", credentials: "include", cache: "no-store" })
    .then(async response => {
      if (!response.ok) return null;
      const data = await response.json() as AuthSession;
      if (typeof data.accessToken !== "string" || !data.user || typeof data.user.id !== "string") return null;
      setAccessToken(data.accessToken);
      return data;
    })
    .catch(() => null)
    .finally(() => { refreshRequest = null; });
  return refreshRequest;
}
export async function api<T = any>(path: string, init: RequestInit = {}): Promise<T> {
  const send = () => {
    const headers = new Headers(init.headers);
    if (init.body && !headers.has("content-type")) headers.set("content-type", "application/json");
    if (accessToken) headers.set("authorization", `Bearer ${accessToken}`);
    return fetch(`${API_URL}${path}`, { ...init, headers, credentials: "include", cache: "no-store" });
  };
  let response = await send();
  if (response.status === 401 && !path.startsWith("/auth/") && await refreshSession()) response = await send();
  const body = response.status === 204 ? null : await response.json().catch(() => null);
  if (!response.ok) throw new Error(body?.error ?? `Request failed (${response.status})`);
  return body as T;
}
export const post = <T = any>(path: string, data?: unknown) => api<T>(path, { method: "POST", body: JSON.stringify(data ?? {}) });
