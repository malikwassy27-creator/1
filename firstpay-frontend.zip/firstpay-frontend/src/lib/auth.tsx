"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { post, refreshSession, setAccessToken, type ApiUser } from "@/lib/api";

type User = ApiUser;
type Auth = { user: User | null; loading: boolean; login(email: string, password: string): Promise<void>; register(email: string, password: string): Promise<void>; logout(): void };
const Context = createContext<Auth | null>(null);
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null); const [loading, setLoading] = useState(true);
  useEffect(() => { let cancelled = false; refreshSession().then(result => { if (cancelled) return; if (result) { setAccessToken(result.accessToken); setUser(result.user); } else setAccessToken(null); }).finally(() => { if (!cancelled) setLoading(false); }); return () => { cancelled = true; }; }, []);
  const login = async (email: string, password: string) => { const result = await post<{ accessToken: string; user: User }>("/auth/login", { email, password }); setAccessToken(result.accessToken); setUser(result.user); };
  const register = async (email: string, password: string) => { await post("/auth/register", { email, password }); await login(email, password); };
  const logout = () => { setAccessToken(null); setUser(null); void post("/auth/logout").catch(() => undefined); };
  return <Context.Provider value={{ user, loading, login, register, logout }}>{children}</Context.Provider>;
}
export function useAuth() { const value = useContext(Context); if (!value) throw new Error("AuthProvider is missing"); return value; }
export function RequireAuth({ children, admin = false }: { children: React.ReactNode; admin?: boolean }) {
  const { user, loading } = useAuth(); const router = useRouter();
  useEffect(() => { if (!loading && (!user || (admin && user.role !== "ADMIN"))) router.replace(user ? "/lobby" : "/login"); }, [loading, user, admin, router]);
  if (loading || !user || (admin && user.role !== "ADMIN")) return <div className="page-state">Checking your session…</div>;
  return children;
}
