"use client";
import { RequireAuth } from "@/lib/auth";
export function PlayerOnly({ children }: { children: React.ReactNode }) { return <RequireAuth>{children}</RequireAuth>; }
export function AdminOnly({ children }: { children: React.ReactNode }) { return <RequireAuth admin>{children}</RequireAuth>; }
